--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.10
-- Dumped by pg_dump version 12.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE pos;
--
-- Name: pos; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE pos WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_Indonesia.1252' LC_CTYPE = 'English_Indonesia.1252';


ALTER DATABASE pos OWNER TO postgres;

\connect pos

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: m_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.m_category (
    id integer NOT NULL,
    image character varying,
    status boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    name character varying
);


ALTER TABLE public.m_category OWNER TO postgres;

--
-- Name: m_customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.m_customer (
    id integer NOT NULL,
    name character varying,
    address character varying,
    email character varying,
    phone character varying,
    status character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.m_customer OWNER TO postgres;

--
-- Name: m_product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.m_product (
    id integer NOT NULL,
    name character varying,
    stock integer,
    buy_price integer,
    sell_price integer,
    category_id integer,
    quantity_id integer,
    type_id integer,
    image character varying,
    status boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.m_product OWNER TO postgres;

--
-- Name: m_quantity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.m_quantity (
    id integer NOT NULL,
    name character varying,
    status boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.m_quantity OWNER TO postgres;

--
-- Name: m_supplier; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.m_supplier (
    id integer NOT NULL,
    name character varying,
    address character varying,
    phone character varying,
    email character varying,
    status boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.m_supplier OWNER TO postgres;

--
-- Name: m_table; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.m_table (
    id integer NOT NULL,
    number character varying,
    area character varying,
    capacity character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.m_table OWNER TO postgres;

--
-- Name: r_menu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.r_menu (
    id integer NOT NULL,
    name character varying
);


ALTER TABLE public.r_menu OWNER TO postgres;

--
-- Name: r_payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.r_payment (
    id integer NOT NULL,
    name character varying
);


ALTER TABLE public.r_payment OWNER TO postgres;

--
-- Name: r_payment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.r_payment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_payment_id_seq OWNER TO postgres;

--
-- Name: r_payment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.r_payment_id_seq OWNED BY public.r_payment.id;


--
-- Name: r_role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.r_role (
    id integer NOT NULL,
    role character varying
);


ALTER TABLE public.r_role OWNER TO postgres;

--
-- Name: r_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.r_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_role_id_seq OWNER TO postgres;

--
-- Name: r_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.r_role_id_seq OWNED BY public.r_role.id;


--
-- Name: r_status_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.r_status_order (
    id integer NOT NULL,
    name character varying
);


ALTER TABLE public.r_status_order OWNER TO postgres;

--
-- Name: r_status_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.r_status_order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_status_order_id_seq OWNER TO postgres;

--
-- Name: r_status_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.r_status_order_id_seq OWNED BY public.r_status_order.id;


--
-- Name: r_submenu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.r_submenu (
    id integer NOT NULL,
    menu_id integer,
    name character varying
);


ALTER TABLE public.r_submenu OWNER TO postgres;

--
-- Name: r_submenu_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.r_submenu_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_submenu_id_seq OWNER TO postgres;

--
-- Name: r_submenu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.r_submenu_id_seq OWNED BY public.r_submenu.id;


--
-- Name: r_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.r_type (
    id integer NOT NULL,
    name character varying
);


ALTER TABLE public.r_type OWNER TO postgres;

--
-- Name: r_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.r_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.r_type_id_seq OWNER TO postgres;

--
-- Name: r_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.r_type_id_seq OWNED BY public.r_type.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    email character varying,
    name character varying,
    role_id integer,
    password character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public."user".id;


--
-- Name: x_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.x_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.x_category_id_seq OWNER TO postgres;

--
-- Name: x_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.x_category_id_seq OWNED BY public.m_category.id;


--
-- Name: x_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.x_customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.x_customer_id_seq OWNER TO postgres;

--
-- Name: x_customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.x_customer_id_seq OWNED BY public.m_customer.id;


--
-- Name: x_menu_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.x_menu_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.x_menu_id_seq OWNER TO postgres;

--
-- Name: x_menu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.x_menu_id_seq OWNED BY public.r_menu.id;


--
-- Name: x_product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.x_product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.x_product_id_seq OWNER TO postgres;

--
-- Name: x_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.x_product_id_seq OWNED BY public.m_product.id;


--
-- Name: x_puchase; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.x_puchase (
    id integer NOT NULL,
    transaction_code character varying,
    date date,
    supplier_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    created_by integer
);


ALTER TABLE public.x_puchase OWNER TO postgres;

--
-- Name: x_puchase_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.x_puchase_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.x_puchase_id_seq OWNER TO postgres;

--
-- Name: x_puchase_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.x_puchase_id_seq OWNED BY public.x_puchase.id;


--
-- Name: x_purchase_detail; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.x_purchase_detail (
    id integer NOT NULL,
    product_id integer,
    price integer,
    qty integer,
    total integer,
    purchase_id integer
);


ALTER TABLE public.x_purchase_detail OWNER TO postgres;

--
-- Name: x_purchase_detail_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.x_purchase_detail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.x_purchase_detail_id_seq OWNER TO postgres;

--
-- Name: x_purchase_detail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.x_purchase_detail_id_seq OWNED BY public.x_purchase_detail.id;


--
-- Name: x_quantity_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.x_quantity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.x_quantity_id_seq OWNER TO postgres;

--
-- Name: x_quantity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.x_quantity_id_seq OWNED BY public.m_quantity.id;


--
-- Name: x_role_has_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.x_role_has_permission (
    id integer NOT NULL,
    role_id integer,
    menu_id integer
);


ALTER TABLE public.x_role_has_permission OWNER TO postgres;

--
-- Name: x_role_has_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.x_role_has_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.x_role_has_permission_id_seq OWNER TO postgres;

--
-- Name: x_role_has_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.x_role_has_permission_id_seq OWNED BY public.x_role_has_permission.id;


--
-- Name: x_role_has_permission_submenu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.x_role_has_permission_submenu (
    id integer NOT NULL,
    permission_id integer,
    submenu_id integer
);


ALTER TABLE public.x_role_has_permission_submenu OWNER TO postgres;

--
-- Name: x_role_has_permission_submenu_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.x_role_has_permission_submenu_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.x_role_has_permission_submenu_id_seq OWNER TO postgres;

--
-- Name: x_role_has_permission_submenu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.x_role_has_permission_submenu_id_seq OWNED BY public.x_role_has_permission_submenu.id;


--
-- Name: x_sale; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.x_sale (
    id integer NOT NULL,
    customer_id integer,
    table_id integer,
    status_order_id integer,
    total integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    transaction_code character varying,
    status_payment_id integer
);


ALTER TABLE public.x_sale OWNER TO postgres;

--
-- Name: x_sale_detail; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.x_sale_detail (
    id integer NOT NULL,
    product_id integer,
    qty integer,
    sale_id integer
);


ALTER TABLE public.x_sale_detail OWNER TO postgres;

--
-- Name: x_sale_detail_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.x_sale_detail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.x_sale_detail_id_seq OWNER TO postgres;

--
-- Name: x_sale_detail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.x_sale_detail_id_seq OWNED BY public.x_sale_detail.id;


--
-- Name: x_sale_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.x_sale_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.x_sale_id_seq OWNER TO postgres;

--
-- Name: x_sale_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.x_sale_id_seq OWNED BY public.x_sale.id;


--
-- Name: x_supplier_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.x_supplier_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.x_supplier_id_seq OWNER TO postgres;

--
-- Name: x_supplier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.x_supplier_id_seq OWNED BY public.m_supplier.id;


--
-- Name: x_table_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.x_table_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.x_table_id_seq OWNER TO postgres;

--
-- Name: x_table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.x_table_id_seq OWNED BY public.m_table.id;


--
-- Name: m_category id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.m_category ALTER COLUMN id SET DEFAULT nextval('public.x_category_id_seq'::regclass);


--
-- Name: m_customer id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.m_customer ALTER COLUMN id SET DEFAULT nextval('public.x_customer_id_seq'::regclass);


--
-- Name: m_product id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.m_product ALTER COLUMN id SET DEFAULT nextval('public.x_product_id_seq'::regclass);


--
-- Name: m_quantity id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.m_quantity ALTER COLUMN id SET DEFAULT nextval('public.x_quantity_id_seq'::regclass);


--
-- Name: m_supplier id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.m_supplier ALTER COLUMN id SET DEFAULT nextval('public.x_supplier_id_seq'::regclass);


--
-- Name: m_table id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.m_table ALTER COLUMN id SET DEFAULT nextval('public.x_table_id_seq'::regclass);


--
-- Name: r_menu id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.r_menu ALTER COLUMN id SET DEFAULT nextval('public.x_menu_id_seq'::regclass);


--
-- Name: r_payment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.r_payment ALTER COLUMN id SET DEFAULT nextval('public.r_payment_id_seq'::regclass);


--
-- Name: r_role id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.r_role ALTER COLUMN id SET DEFAULT nextval('public.r_role_id_seq'::regclass);


--
-- Name: r_status_order id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.r_status_order ALTER COLUMN id SET DEFAULT nextval('public.r_status_order_id_seq'::regclass);


--
-- Name: r_submenu id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.r_submenu ALTER COLUMN id SET DEFAULT nextval('public.r_submenu_id_seq'::regclass);


--
-- Name: r_type id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.r_type ALTER COLUMN id SET DEFAULT nextval('public.r_type_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: x_puchase id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_puchase ALTER COLUMN id SET DEFAULT nextval('public.x_puchase_id_seq'::regclass);


--
-- Name: x_purchase_detail id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_purchase_detail ALTER COLUMN id SET DEFAULT nextval('public.x_purchase_detail_id_seq'::regclass);


--
-- Name: x_role_has_permission id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_role_has_permission ALTER COLUMN id SET DEFAULT nextval('public.x_role_has_permission_id_seq'::regclass);


--
-- Name: x_role_has_permission_submenu id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_role_has_permission_submenu ALTER COLUMN id SET DEFAULT nextval('public.x_role_has_permission_submenu_id_seq'::regclass);


--
-- Name: x_sale id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_sale ALTER COLUMN id SET DEFAULT nextval('public.x_sale_id_seq'::regclass);


--
-- Name: x_sale_detail id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_sale_detail ALTER COLUMN id SET DEFAULT nextval('public.x_sale_detail_id_seq'::regclass);


--
-- Data for Name: m_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.m_category (id, image, status, created_at, updated_at, deleted_at, name) FROM stdin;
\.
COPY public.m_category (id, image, status, created_at, updated_at, deleted_at, name) FROM '$$PATH$$/3021.dat';

--
-- Data for Name: m_customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.m_customer (id, name, address, email, phone, status, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.m_customer (id, name, address, email, phone, status, created_at, updated_at, deleted_at) FROM '$$PATH$$/3031.dat';

--
-- Data for Name: m_product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.m_product (id, name, stock, buy_price, sell_price, category_id, quantity_id, type_id, image, status, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.m_product (id, name, stock, buy_price, sell_price, category_id, quantity_id, type_id, image, status, created_at, updated_at, deleted_at) FROM '$$PATH$$/3025.dat';

--
-- Data for Name: m_quantity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.m_quantity (id, name, status, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.m_quantity (id, name, status, created_at, updated_at, deleted_at) FROM '$$PATH$$/3023.dat';

--
-- Data for Name: m_supplier; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.m_supplier (id, name, address, phone, email, status, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.m_supplier (id, name, address, phone, email, status, created_at, updated_at, deleted_at) FROM '$$PATH$$/3033.dat';

--
-- Data for Name: m_table; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.m_table (id, number, area, capacity, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.m_table (id, number, area, capacity, created_at, updated_at, deleted_at) FROM '$$PATH$$/3029.dat';

--
-- Data for Name: r_menu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.r_menu (id, name) FROM stdin;
\.
COPY public.r_menu (id, name) FROM '$$PATH$$/3017.dat';

--
-- Data for Name: r_payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.r_payment (id, name) FROM stdin;
\.
COPY public.r_payment (id, name) FROM '$$PATH$$/3045.dat';

--
-- Data for Name: r_role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.r_role (id, role) FROM stdin;
\.
COPY public.r_role (id, role) FROM '$$PATH$$/3015.dat';

--
-- Data for Name: r_status_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.r_status_order (id, name) FROM stdin;
\.
COPY public.r_status_order (id, name) FROM '$$PATH$$/3043.dat';

--
-- Data for Name: r_submenu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.r_submenu (id, menu_id, name) FROM stdin;
\.
COPY public.r_submenu (id, menu_id, name) FROM '$$PATH$$/3019.dat';

--
-- Data for Name: r_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.r_type (id, name) FROM stdin;
\.
COPY public.r_type (id, name) FROM '$$PATH$$/3027.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."user" (id, email, name, role_id, password, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public."user" (id, email, name, role_id, password, created_at, updated_at, deleted_at) FROM '$$PATH$$/3012.dat';

--
-- Data for Name: x_puchase; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.x_puchase (id, transaction_code, date, supplier_id, created_at, updated_at, deleted_at, created_by) FROM stdin;
\.
COPY public.x_puchase (id, transaction_code, date, supplier_id, created_at, updated_at, deleted_at, created_by) FROM '$$PATH$$/3035.dat';

--
-- Data for Name: x_purchase_detail; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.x_purchase_detail (id, product_id, price, qty, total, purchase_id) FROM stdin;
\.
COPY public.x_purchase_detail (id, product_id, price, qty, total, purchase_id) FROM '$$PATH$$/3037.dat';

--
-- Data for Name: x_role_has_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.x_role_has_permission (id, role_id, menu_id) FROM stdin;
\.
COPY public.x_role_has_permission (id, role_id, menu_id) FROM '$$PATH$$/3046.dat';

--
-- Data for Name: x_role_has_permission_submenu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.x_role_has_permission_submenu (id, permission_id, submenu_id) FROM stdin;
\.
COPY public.x_role_has_permission_submenu (id, permission_id, submenu_id) FROM '$$PATH$$/3048.dat';

--
-- Data for Name: x_sale; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.x_sale (id, customer_id, table_id, status_order_id, total, created_at, updated_at, deleted_at, transaction_code, status_payment_id) FROM stdin;
\.
COPY public.x_sale (id, customer_id, table_id, status_order_id, total, created_at, updated_at, deleted_at, transaction_code, status_payment_id) FROM '$$PATH$$/3039.dat';

--
-- Data for Name: x_sale_detail; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.x_sale_detail (id, product_id, qty, sale_id) FROM stdin;
\.
COPY public.x_sale_detail (id, product_id, qty, sale_id) FROM '$$PATH$$/3041.dat';

--
-- Name: r_payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.r_payment_id_seq', 1, false);


--
-- Name: r_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.r_role_id_seq', 1, true);


--
-- Name: r_status_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.r_status_order_id_seq', 1, false);


--
-- Name: r_submenu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.r_submenu_id_seq', 11, true);


--
-- Name: r_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.r_type_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: x_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.x_category_id_seq', 1, true);


--
-- Name: x_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.x_customer_id_seq', 1, false);


--
-- Name: x_menu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.x_menu_id_seq', 5, true);


--
-- Name: x_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.x_product_id_seq', 1, false);


--
-- Name: x_puchase_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.x_puchase_id_seq', 1, false);


--
-- Name: x_purchase_detail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.x_purchase_detail_id_seq', 1, false);


--
-- Name: x_quantity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.x_quantity_id_seq', 1, false);


--
-- Name: x_role_has_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.x_role_has_permission_id_seq', 4, true);


--
-- Name: x_role_has_permission_submenu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.x_role_has_permission_submenu_id_seq', 4, true);


--
-- Name: x_sale_detail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.x_sale_detail_id_seq', 1, false);


--
-- Name: x_sale_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.x_sale_id_seq', 1, false);


--
-- Name: x_supplier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.x_supplier_id_seq', 1, false);


--
-- Name: x_table_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.x_table_id_seq', 1, false);


--
-- Name: r_payment r_payment_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.r_payment
    ADD CONSTRAINT r_payment_pk PRIMARY KEY (id);


--
-- Name: r_role r_role_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.r_role
    ADD CONSTRAINT r_role_pk PRIMARY KEY (id);


--
-- Name: r_status_order r_status_order_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.r_status_order
    ADD CONSTRAINT r_status_order_pk PRIMARY KEY (id);


--
-- Name: r_submenu r_submenu_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.r_submenu
    ADD CONSTRAINT r_submenu_pk PRIMARY KEY (id);


--
-- Name: r_type r_type_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.r_type
    ADD CONSTRAINT r_type_pk PRIMARY KEY (id);


--
-- Name: user users_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT users_pk PRIMARY KEY (id);


--
-- Name: m_category x_category_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.m_category
    ADD CONSTRAINT x_category_pk PRIMARY KEY (id);


--
-- Name: m_customer x_customer_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.m_customer
    ADD CONSTRAINT x_customer_pk PRIMARY KEY (id);


--
-- Name: r_menu x_menu_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.r_menu
    ADD CONSTRAINT x_menu_pk PRIMARY KEY (id);


--
-- Name: m_product x_product_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.m_product
    ADD CONSTRAINT x_product_pk PRIMARY KEY (id);


--
-- Name: x_puchase x_puchase_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_puchase
    ADD CONSTRAINT x_puchase_pk PRIMARY KEY (id);


--
-- Name: x_purchase_detail x_purchase_detail_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_purchase_detail
    ADD CONSTRAINT x_purchase_detail_pk PRIMARY KEY (id);


--
-- Name: m_quantity x_quantity_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.m_quantity
    ADD CONSTRAINT x_quantity_pk PRIMARY KEY (id);


--
-- Name: x_role_has_permission x_role_has_permission_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_role_has_permission
    ADD CONSTRAINT x_role_has_permission_pk PRIMARY KEY (id);


--
-- Name: x_role_has_permission_submenu x_role_has_permission_submenu_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_role_has_permission_submenu
    ADD CONSTRAINT x_role_has_permission_submenu_pk PRIMARY KEY (id);


--
-- Name: x_sale_detail x_sale_detail_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_sale_detail
    ADD CONSTRAINT x_sale_detail_pk PRIMARY KEY (id);


--
-- Name: x_sale x_sale_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_sale
    ADD CONSTRAINT x_sale_pk PRIMARY KEY (id);


--
-- Name: m_supplier x_supplier_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.m_supplier
    ADD CONSTRAINT x_supplier_pk PRIMARY KEY (id);


--
-- Name: m_table x_table_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.m_table
    ADD CONSTRAINT x_table_pk PRIMARY KEY (id);


--
-- Name: r_submenu r_submenu_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.r_submenu
    ADD CONSTRAINT r_submenu_fk FOREIGN KEY (menu_id) REFERENCES public.r_menu(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: user users_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT users_fk FOREIGN KEY (role_id) REFERENCES public.r_role(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: m_product x_product_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.m_product
    ADD CONSTRAINT x_product_fk FOREIGN KEY (category_id) REFERENCES public.m_category(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: m_product x_product_fk_qty; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.m_product
    ADD CONSTRAINT x_product_fk_qty FOREIGN KEY (quantity_id) REFERENCES public.m_quantity(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: m_product x_product_fk_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.m_product
    ADD CONSTRAINT x_product_fk_type FOREIGN KEY (type_id) REFERENCES public.r_type(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: x_puchase x_puchase_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_puchase
    ADD CONSTRAINT x_puchase_fk FOREIGN KEY (supplier_id) REFERENCES public.m_supplier(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: x_puchase x_puchase_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_puchase
    ADD CONSTRAINT x_puchase_fk_2 FOREIGN KEY (created_by) REFERENCES public."user"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: x_purchase_detail x_purchase_detail_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_purchase_detail
    ADD CONSTRAINT x_purchase_detail_fk FOREIGN KEY (product_id) REFERENCES public.m_product(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: x_purchase_detail x_purchase_detail_fk_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_purchase_detail
    ADD CONSTRAINT x_purchase_detail_fk_id FOREIGN KEY (purchase_id) REFERENCES public.x_puchase(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: x_role_has_permission x_role_has_permission_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_role_has_permission
    ADD CONSTRAINT x_role_has_permission_fk FOREIGN KEY (role_id) REFERENCES public.r_role(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: x_role_has_permission x_role_has_permission_fk_menu; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_role_has_permission
    ADD CONSTRAINT x_role_has_permission_fk_menu FOREIGN KEY (menu_id) REFERENCES public.r_menu(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: x_role_has_permission_submenu x_role_has_permission_submenu_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_role_has_permission_submenu
    ADD CONSTRAINT x_role_has_permission_submenu_fk FOREIGN KEY (permission_id) REFERENCES public.x_role_has_permission(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: x_role_has_permission_submenu x_role_has_permission_submenu_fk_submenu; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_role_has_permission_submenu
    ADD CONSTRAINT x_role_has_permission_submenu_fk_submenu FOREIGN KEY (submenu_id) REFERENCES public.r_submenu(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: x_sale_detail x_sale_detail_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_sale_detail
    ADD CONSTRAINT x_sale_detail_fk FOREIGN KEY (sale_id) REFERENCES public.x_sale(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: x_sale_detail x_sale_detail_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_sale_detail
    ADD CONSTRAINT x_sale_detail_fk_1 FOREIGN KEY (product_id) REFERENCES public.m_product(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: x_sale x_sale_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_sale
    ADD CONSTRAINT x_sale_fk FOREIGN KEY (customer_id) REFERENCES public.m_customer(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: x_sale x_sale_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_sale
    ADD CONSTRAINT x_sale_fk_2 FOREIGN KEY (table_id) REFERENCES public.m_table(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: x_sale x_sale_fk_3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_sale
    ADD CONSTRAINT x_sale_fk_3 FOREIGN KEY (status_payment_id) REFERENCES public.r_payment(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: x_sale x_sale_fk_4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_sale
    ADD CONSTRAINT x_sale_fk_4 FOREIGN KEY (status_order_id) REFERENCES public.r_status_order(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

